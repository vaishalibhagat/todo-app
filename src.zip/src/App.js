import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faComments } from "@fortawesome/free-solid-svg-icons";
import CrewList from "./components/crewlist/CrewList";

import ToDoList from "./components/firsttodolist/PersonalTodo";
import Chat from "./components/chat/Chat";
import ProductDetails from "./components/productdetails/ProductDetails";
import "./components/style.css";
import ToDoSection from "./components/todosection/GroupTodo";
import MilestoneList from "./components/MilestoneList";
import TaskList from "./components/tasklist/AssignTodo";
import Resources from "./components/resources/Resources";
import PersonalTodo from "./components/firsttodolist/PersonalTodo";
import GroupTodo from "./components/todosection/GroupTodo";
import AssignTodo from "./components/tasklist/AssignTodo";

function App() {
  const [isChatOpen, setIsChatOpen] = useState(false);

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  return (
    <div className="container">
      <div className="main-content">
        <div className="left-sidebar">
          <div className="product-details-section">
            <ProductDetails />
          </div>
          <div className="crew-list-section">
            <CrewList />
          </div>
          <div className="resources-section">
            <Resources />
          </div>
        </div>

        <div className={`chat-section ${isChatOpen ? "open" : ""}`}>
          <Chat />
        </div>

        <div className="right-sidebar">
          {/* <ToDoList /> */}
          <PersonalTodo />
          <GroupTodo />
          <AssignTodo />
        </div>
      </div>

      {/* Floating chat icon */}
      <div className="chat-icon" onClick={toggleChat}>
        <FontAwesomeIcon icon={faComments} className="chat-icon-fa" />
      </div>
    </div>
  );
}

export default App;
