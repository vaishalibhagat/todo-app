import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUserPlus } from "@fortawesome/free-solid-svg-icons";
import "./CrewList.css";
const crewData = [
  { name: "Member Name", role: "Lead - Software Developer" },
  { name: "Member Name", role: "Lead - Software Developer" },
  { name: "Member Name", role: "Lead - Software Developer" },
  { name: "Member Name", role: "Lead - Software Developer" },
];

function CrewList() {
  return (
    <div className="crew-list-sections">
      <h3>Crew ({crewData.length} members)</h3>
      <ul className="crew-member-list">
        {crewData.map((member, index) => (
          <li className="crew-member" key={index}>
            <div className="member-info">
              <div className="avatar"></div>
              <div className="member-details">
                <p className="member-name">{member.name}</p>
                <p className="member-role">{member.role}</p>
              </div>
            </div>
            <button className="remove-btns">-</button>
          </li>
        ))}
      </ul>
      <button className="add-btn-crew">
        <FontAwesomeIcon icon={faUserPlus} className="add-btn-icon" />
        Add new members
      </button>
    </div>
  );
}

export default CrewList;
