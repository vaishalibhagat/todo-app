import React from "react";
import "./ProductDetails.css";

function ProductDetails() {
  return (
    <div className="product-details-section">
      <h1>Intranet Portal - FrontEnd</h1>
      <div className="project-info">
        <p>
          <strong>Captain:</strong> Manager Name
        </p>
        <p>
          <strong>Created On:</strong> 21-08-2024
        </p>
      </div>
      <p className="project-description">
        Here we will only discuss about the front-end design and front-end
        development.
      </p>
    </div>
  );
}

export default ProductDetails;
