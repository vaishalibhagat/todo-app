import React from "react";
import "./TaskList.css";
import img2 from "./img2.jpg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheck } from "@fortawesome/free-solid-svg-icons";
const taskData = [
  {
    title: "Chat Front-end matching exactly with the design",
    dueDate: "04/04/2024",
    members: ["Member1", "Member2", "Member3"], // Replace with actual image URLs for avatars
  },
  {
    title: "Chat Front-end matching exactly with the design",
    dueDate: "04/04/2024",
    members: ["Member1", "Member2", "Member3"],
  },
  {
    title: "Chat Front-end matching exactly with the design",
    dueDate: "04/04/2024",
    members: ["Member1", "Member2", "Member3"],
  },
];

function AssignTodo() {
  return (
    <div className="task-section">
      <div className="tasks-list">
        {taskData.map((task, index) => (
          <div key={index}>
            <div className="task-item">
              <p className="tasks-title">{task.title}</p>
              <div className="tasks-actions">
                <button className="complete-btns">
                  <FontAwesomeIcon icon={faCheck} className="check-btn-icon" />
                </button>
                <button className="remove-btns">-</button>
              </div>
            </div>
            <div className="tasks-item">
              <p className="tasks-duedate">Due Date: 03/04/2024</p>
              <div className="tasks-members">
                {task.members.map((member, i) => (
                  <div key={i} className="member-avatar">
                    {member[0]}
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default AssignTodo;
