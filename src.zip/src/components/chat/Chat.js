import React from "react";
import "./Chat.css";

function Chat() {
  return <div className="chat-container"></div>;
}

export default Chat;
