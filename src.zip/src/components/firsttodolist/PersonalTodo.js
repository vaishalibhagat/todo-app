import React, { useState } from "react";
import "../todosection/ToDoSection.css";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheck, faPlus } from "@fortawesome/free-solid-svg-icons";

const todoData = [
  {
    date: "24/04",
    task: "Completion of Sites - Subsites front-end with color themes",
  },
  {
    date: "24/04",
    task: "Completion of Sites - Subsites front-end with color themes",
  },
  {
    date: "24/04",
    task: "Completion of Sites - Subsites front-end with color themes",
  },
  {
    date: "24/04",
    task: "Completion of Sites - Subsites front-end with color themes",
  },
];

function PersonalTodo() {
  return (
    <div className="todo-section">
      <ul className="todo-item-list">
        {todoData.map((item, index) => (
          <li key={index} className="todo-item">
            <div className="todo-date">{item.date}</div>
            <div className="todo-details">
              <p className="task-name">{item.task}</p>
              <div className="todo-actions">
                <button className="complete-btn">
                  <FontAwesomeIcon icon={faCheck} className="check-btn-icon" />
                </button>
                <button className="remove-btn">-</button>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default PersonalTodo;
